sap.ui.define([
	"HelloJBNamespace/HelloJB/test/unit/controller/HelloJBView.controller"
], function () {
	"use strict";
});
